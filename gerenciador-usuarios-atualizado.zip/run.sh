#!/bin/bash

echo "Instalando dependências..."
pnpm install

echo "Iniciando o servidor de desenvolvimento..."
pnpm run dev --host


