import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Users, RefreshCw, Edit3, Database, Loader2, LogOut } from 'lucide-react'
import { UserCard } from '@/components/UserCard'
import { BulkEditModal } from '@/components/BulkEditModal'
import { getUsers, updateMultipleUsersLocal, syncWithSupabase } from '@/lib/userService'
import { toast, Toaster } from 'sonner'
import { supabase } from './lib/supabase'
import Login from './components/Login'
import './App.css'

function App() {
  const [users, setUsers] = useState([])
  const [selectedUsers, setSelectedUsers] = useState([])
  const [showBulkEdit, setShowBulkEdit] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isSyncing, setIsSyncing] = useState(false)
  const [lastSync, setLastSync] = useState(null)
  const [session, setSession] = useState(null)

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
    })

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session)
    })

    return () => subscription.unsubscribe()
  }, [])

  // Carregar usuários ao inicializar
  useEffect(() => {
    if (session) {
      loadUsers()
    }
  }, [session])

  const loadUsers = async () => {
    setIsLoading(true)
    try {
      const { data, error } = await getUsers()
      if (error) {
        toast.error('Erro ao carregar usuários: ' + error)
        return
      }
      setUsers(data || [])
    } catch (error) {
      toast.error('Erro inesperado ao carregar usuários')
      console.error('Erro ao carregar usuários:', error)
    } finally {
      setIsLoading(false)
    }
  }

  // Gerenciar seleção de usuários
  const handleSelectUser = (userId, checked) => {
    if (checked) {
      setSelectedUsers(prev => [...prev, userId])
    } else {
      setSelectedUsers(prev => prev.filter(id => id !== userId))
    }
  }

  const handleSelectAll = (checked) => {
    if (checked) {
      setSelectedUsers(users.map(user => user.id))
    } else {
      setSelectedUsers([])
    }
  }

  const isAllSelected = selectedUsers.length === users.length && users.length > 0
  const isPartiallySelected = selectedUsers.length > 0 && selectedUsers.length < users.length

  // Atualizar usuário individual
  const handleUserUpdate = (updatedUser) => {
    setUsers(prev => prev.map(user => 
      user.id === updatedUser.id ? updatedUser : user
    ))
  }

  // Edição em massa (apenas local)
  const handleBulkEdit = async (updates) => {
    if (selectedUsers.length === 0) {
      toast.error("Selecione pelo menos um usuário")
      return
    }

    try {
      const { data, error, skippedUsers } = await updateMultipleUsersLocal(selectedUsers, updates)
      
      if (error) {
        toast.error("Erro ao atualizar usuários: " + error)
        return
      }

      // Atualizar usuários na interface
      data.forEach(updatedUser => {
        handleUserUpdate(updatedUser)
      })

      // Mensagem de sucesso com informações sobre usuários ignorados
      let message = `${data.length} usuários atualizados localmente!`
      if (skippedUsers && skippedUsers.length > 0) {
        message += ` (${skippedUsers.length} usuários com saldo zerado foram ignorados)`
      }
      
      toast.success(message)
      setSelectedUsers([])
    } catch (error) {
      toast.error("Erro inesperado ao atualizar usuários em massa")
      console.error("Erro na edição em massa:", error)
    }
  }

  // Sincronizar com Supabase
  const handleSync = async () => {
    setIsSyncing(true)
    try {
      const { data, error, partialSuccess } = await syncWithSupabase()
      
      if (error && !partialSuccess) {
        toast.error("Erro ao sincronizar com Supabase: " + error)
        return
      }

      if (partialSuccess) {
        toast.warning(`Sincronização parcial: ${data.length} usuários sincronizados`)
      } else {
        toast.success(`${data.length} usuários sincronizados com sucesso!`)
      }

      setLastSync(new Date())
      // Recarregar dados do Supabase
      await loadUsers()
    } catch (error) {
      toast.error("Erro inesperado ao sincronizar")
      console.error("Erro na sincronização:", error)
    } finally {
      setIsSyncing(false)
    }
  }

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut()
    if (error) {
      toast.error('Erro ao fazer logout: ' + error.message)
    } else {
      toast.success('Logout bem-sucedido!')
      setUsers([])
      setSelectedUsers([])
    }
  }

  const selectedUsersData = users.filter(user => selectedUsers.includes(user.id))

  if (!session) {
    return <Login onLogin={() => {}} />;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="flex items-center gap-2">
          <Loader2 className="h-6 w-6 animate-spin" />
          <span>Carregando usuários...</span>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-gray-900">Gerenciador de Usuários Supabase</h1>
          <p className="text-gray-600">Gerencie usuários com edição individual, em massa e sincronização</p>
        </div>

        {/* Controles principais */}
        <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            <span className="font-medium">{users.length} usuários carregados</span>
            {lastSync && (
              <Badge variant="outline" className="text-xs">
                Última sync: {lastSync.toLocaleTimeString()}
              </Badge>
            )}
          </div>
          
          <div className="flex gap-2">
            <Button onClick={loadUsers} variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              Recarregar
            </Button>
            <Button 
              onClick={handleSync} 
              disabled={isSyncing}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isSyncing ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Database className="h-4 w-4 mr-2" />
              )}
              Sincronizar Supabase
            </Button>
            <Button 
              onClick={handleLogout} 
              variant="destructive" 
              size="sm"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>

        {/* Controles de seleção em massa */}
        {users.length > 0 && (
          <Card className="border-2 border-dashed border-gray-300 bg-gray-50">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-3 p-2 bg-white rounded-lg border-2 border-blue-200 shadow-sm">
                    <Checkbox
                      checked={isAllSelected}
                      onCheckedChange={handleSelectAll}
                      ref={(el) => {
                        if (el) el.indeterminate = isPartiallySelected
                      }}
                      className="w-5 h-5 border-2 border-blue-500 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                    />
                    <div>
                      <CardTitle className="text-base font-semibold text-gray-900">
                        {selectedUsers.length > 0 
                          ? `${selectedUsers.length} usuário(s) selecionado(s)`
                          : 'Selecionar todos os usuários'
                        }
                      </CardTitle>
                      {selectedUsers.length > 0 && (
                        <CardDescription className="text-sm text-gray-600">
                          Clique em "Editar em Massa" para aplicar valores a todos os selecionados
                        </CardDescription>
                      )}
                    </div>
                  </div>
                </div>
                
                {selectedUsers.length > 0 && (
                  <Button 
                    onClick={() => setShowBulkEdit(true)}
                    className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700"
                    size="lg"
                  >
                    <Edit3 className="h-4 w-4" />
                    Editar em Massa
                  </Button>
                )}
              </div>
            </CardHeader>
          </Card>
        )}

        {/* Lista de usuários */}
        {users.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Users className="h-12 w-12 text-gray-400 mb-4" />
              <p className="text-lg font-medium text-gray-500">Nenhum usuário encontrado.</p>
              <p className="text-sm text-gray-400">Os usuários aparecerão aqui quando estiverem disponíveis.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {users.map((user) => (
              <UserCard
                key={user.id}
                user={user}
                onUserUpdate={handleUserUpdate}
                isSelected={selectedUsers.includes(user.id)}
                onSelectionChange={(checked) => handleSelectUser(user.id, checked)}
              />
            ))}
          </div>
        )}

        {/* Modal de edição em massa */}
        <BulkEditModal
          isOpen={showBulkEdit}
          onClose={() => setShowBulkEdit(false)}
          selectedUsers={selectedUsersData}
          onSave={handleBulkEdit}
        />
      </div>
      <Toaster richColors position="top-right" />
    </div>
  )
}

export default App


